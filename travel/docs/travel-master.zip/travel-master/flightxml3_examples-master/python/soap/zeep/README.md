Requirements
------------

* python (tested with 2.7.10)
* lxml (3.7.3. pip install lxml==3.7.3)
* zeep (pip install zeep)

What to change
-------------

Substitute your actual username and API key in the get_flights_enroute.py file.

Running the example
-------------------
./get_flights_enroute.py

OR

python get_flights_enroute.py