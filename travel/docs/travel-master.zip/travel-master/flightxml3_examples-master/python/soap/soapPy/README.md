Requirements
------------

* python (tested with 2.7.10)
* SOAPpy (pip install SOAPpy)
* wstools (v0.4.3 or v0.4.6)

What to change
-------------

Substitute your actual username and API key in the get_flights_enroute.py file.

Running the example
-------------------
./get_flights_enroute.py

OR

python get_flights_enroute.py