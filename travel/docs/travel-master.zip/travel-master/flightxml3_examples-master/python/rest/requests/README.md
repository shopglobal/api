Requirements
------------

* python 
* requests (pip install requests)

What to change
-------------

Substitute your actual username and API key in the get_flights_enroute.py file.

Running the example
-------------------
./get_flights_enroute.py

OR

python fget_flights_enroute.py