Requirements
------------

* perl (tested using v5.18)
* SOAP::Lite (tested with 3.21)

What to change
-------------

Substitute your actual username and API key in the get_enroute_flights.pl script.

Running the example
-------------------
perl get_enroute_flights.pl 

or

./get_enroute_flights.pl