Requirements
------------

* perl (tested using v5.18)
* XML::Compile::SOAP11 (tested with 3.21)
* XML::Compile::WSDL11 (tested with 3.06)

What to change
-------------

Substitute your actual username and API key in the get_flight_track.pl script.

Running the example
-------------------
perl get_flight_track.pl 

or

./get_flight_track.pl