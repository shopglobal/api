Requirements
------------

* Ruby >= 2.0
* json (gem install json)
* rest-client (gem install rest-client)

What to change
-------------

Substitute your actual username and API key in the get_flights_enroute.rb file.

Running the example
-------------------
./get_flights_enroute.rb

OR

ruby get_flights_enroute.rb