Requirements
------------

* PHP >= 5.6
* Web Server (Apache/Nginx/IIS)

What to change
-------------

Substitute your actual username and API key in the executeCurlRequest method in the
flightxml_query.php file.

Running the example
-------------------
Copy the example files to your web server's document root or configure
your web server to host the project.