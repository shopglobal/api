Requirements
------------

* PHP >= 5.6
* Composer
* Web Server (Apache/Nginx/IIS)

What to change
-------------

Substitute your actual username and API key in the auth_info array in the
flightxml_query.php file.

Running the example
-------------------
To install the guzzle dependency run:
composer install

Then copy the example files to your web server's document root or configure
your web server to host the project.