Requirements
------------

* Visual Studio (created with VS2017)
* .NET

What to change
-------------

Substitute your actual username and API key in Program.cs.

Running the example
-------------------
Open the app in Visual Studio and run it.

To update or reimport the wsdl, right click on FlightXML3 under Connected Services and select Update Service Reference.