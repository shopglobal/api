Requirements
------------

* ColdFusion 8 or newer

What to change
-------------

Substitute your actual username and API key in the flightxml_example.cfm file.

Running the example
-------------------
Load the script in your ColdFusion instance