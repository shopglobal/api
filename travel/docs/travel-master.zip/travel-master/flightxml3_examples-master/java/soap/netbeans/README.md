Requirements
------------

* Java 1.8
* Netbeans IDE >= 8

What to change
-------------

Substitute your actual username and API key in the MyFlightXML3 class.

Running the example
-------------------
1. Open the project into Netbeans
2. Generate the WSDL class files
  1. Expand the Web Service References folder
  2. Right click on 'wsdl' and select 'Refresh...'
  3. Select 'Yes' to confirm the action
3. Run the Java Application with the entry class MyFlightXML3
