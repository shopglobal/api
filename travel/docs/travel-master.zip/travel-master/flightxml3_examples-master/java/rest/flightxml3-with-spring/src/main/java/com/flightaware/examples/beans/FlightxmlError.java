package com.flightaware.examples.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by jonathan.cone on 5/8/17.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FlightxmlError {

    private String error;

}
