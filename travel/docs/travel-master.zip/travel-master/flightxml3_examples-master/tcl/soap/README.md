Requirements
------------

* tcl >= 8.5
* TCLws >= 2.4 (https://core.tcl.tk/tclws/index)

What to change
-------------

Substitute your actual username and API key in the flightxml_example.tcl file.

Running the example
-------------------
./flightxml_example.tcl

OR

tclsh flightxml_example.tcl