Requirements
------------

* tcl >= 8.5
* yajltcl (https://github.com/flightaware/yajl-tcl)

What to change
-------------

Substitute your actual username and API key in the flightxml_example.tcl file.

Running the example
-------------------
./flightxml_example.tcl

OR

tclsh flightxml_example.tcl