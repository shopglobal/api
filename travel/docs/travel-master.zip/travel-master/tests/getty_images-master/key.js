/*jshint esversion: 6*/
module.exports = () =>{
  const key = 'sngkdsdagt8mg6ec5czdsvye';
};