module.exports = require('./dist/theater.js')
